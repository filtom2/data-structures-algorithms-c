#include <stdio.h>
#include <stdlib.h>

#define INT_MAX 2147483647

typedef struct edge {
    int vrchol1;
    int vrchol2;
    int vaha;
    struct edge* next;
} EDGE;


typedef struct vertex{
    EDGE* head;  
} VERTEX;


typedef struct graph{
    VERTEX* vertices;
    int velkostGrafu;
} GRAPH;


typedef struct heapNode{
    int vertex; 
    int distance; 
} HEAPNODE;

typedef struct minHeap{
    HEAPNODE *nodes;
    int velkost;
    int kapacita;
    int *pozicia; 
} MINHEAP;


GRAPH* createGraph(int pocetVrcholov) {
    GRAPH* grafik = (GRAPH*)malloc(sizeof(GRAPH));
    if (!grafik) {
        return NULL;
    }
    grafik->velkostGrafu = pocetVrcholov;
    grafik->vertices = (VERTEX*)malloc(pocetVrcholov * sizeof(VERTEX));
    if (!grafik->vertices) { 
        free(grafik);
        return NULL;
    }
    for (int i = 0; i < pocetVrcholov; i++) {
        grafik->vertices[i].head = NULL;
    }
    return grafik;
}



int hranaExist(GRAPH* grafik, int v1, int v2) {
    EDGE* current1 = grafik->vertices[v1].head;
    while (current1 != NULL) {
        if (current1->vrchol2 == v2) {
            return 1;
        }
        current1 = current1->next;
    }
    EDGE* current2 = grafik->vertices[v2].head;
    while (current2 != NULL) {
        if (current2->vrchol2 == v1) {
            return 1;
        }
        current2 = current2->next;
    }
    return 0;
}


MINHEAP* createMinHeap(int kapacita) {
    MINHEAP *heap = (MINHEAP *)malloc(sizeof(MINHEAP));
    if (!heap) return NULL;

    heap->nodes = (HEAPNODE *)malloc(kapacita * sizeof(HEAPNODE));
    heap->pozicia = (int *)malloc(kapacita * sizeof(int));
    heap->kapacita = kapacita;
    heap->velkost = 0;

    if (!heap->nodes || !heap->pozicia) {
        free(heap->nodes);
        free(heap->pozicia);
        free(heap);
        return NULL;
    }
    for (int i = 0; i < kapacita; i++) {
        heap->nodes[i] = (HEAPNODE){i, INT_MAX};
        heap->pozicia[i] = i;
    }
    return heap;
}

void swapHeapNodes(HEAPNODE *a, HEAPNODE *b) {
    HEAPNODE temp = *a;
    *a = *b;
    *b = temp;
}

void upravMinHeap(MINHEAP *heap, int index) {
    int smallest = index;
    int left = 2 * index + 1;
    int right = 2 * index + 2;

    if (left < heap->velkost && heap->nodes[left].distance < heap->nodes[smallest].distance) {
        smallest = left;
    }
    if (right < heap->velkost && heap->nodes[right].distance < heap->nodes[smallest].distance) {
        smallest = right;
    }
    if (smallest != index) {
        heap->pozicia[heap->nodes[smallest].vertex] = index;
        heap->pozicia[heap->nodes[index].vertex] = smallest;
        swapHeapNodes(&heap->nodes[smallest], &heap->nodes[index]);
        upravMinHeap(heap, smallest);
    }
}



HEAPNODE extractMin(MINHEAP *heap) {
   if (heap->velkost <= 0) {
        return (HEAPNODE){-1, 0}; 
    }

    HEAPNODE root = heap->nodes[0];
    HEAPNODE lastNode = heap->nodes[heap->velkost - 1];
    heap->nodes[0] = lastNode;
    heap->pozicia[root.vertex] = heap->velkost - 1;
    heap->pozicia[lastNode.vertex] = 0;
    heap->velkost--;
    upravMinHeap(heap, 0);
    return root;
}

void decreaseKey(MINHEAP *heap, int vertexIndex, int vzdialenost) {
    int x = heap->pozicia[vertexIndex];
    heap->nodes[x].distance = vzdialenost;
    while (x != 0 && heap->nodes[x].distance < heap->nodes[(x - 1) / 2].distance) {
        heap->pozicia[heap->nodes[x].vertex] = (x - 1) / 2;
        heap->pozicia[heap->nodes[(x - 1) / 2].vertex] = x;
        swapHeapNodes(&heap->nodes[x], &heap->nodes[(x - 1) / 2]);
        x = (x - 1) / 2;
    }
}

int isInMinHeap(MINHEAP *heap, int IndexVrcholu) {
    return heap->pozicia[IndexVrcholu] < heap->velkost ? 1 : 0;
}


int deleteEdge(GRAPH* grafik, int v1, int v2) {
    int zhoda = 0;
    int uvolnenie = 0;
    
    EDGE **current = &(grafik->vertices[v1].head);
    while (*current != NULL) {
        EDGE *entry = *current;
        if (entry->vrchol2 == v2) {
            *current = entry->next;
            if(!uvolnenie){
                free(entry); 
                uvolnenie = 1;
            }
            zhoda = 1;
            break; 
        }
        current = &((*current)->next);
    }
    current = &(grafik->vertices[v2].head);
    while (*current != NULL) {
        EDGE *entry = *current;
        if (entry->vrchol2 == v1) {
            *current = entry->next;
            if(!uvolnenie){
                free(entry); 
                uvolnenie = 1;
            }
            zhoda = 1;
            break; 
        }
        current = &((*current)->next);
    }
    return zhoda;
}




int addEdgeToGraph(GRAPH* grafik, int zdroj, int ciel, int weight) {
    EDGE* newEdge = (EDGE*) malloc(sizeof(EDGE));
    if (!newEdge) {
        return 0; 
    }
    newEdge->vrchol1 = zdroj;
    newEdge->vrchol2 = ciel;
    newEdge->vaha = weight;
    newEdge->next = grafik->vertices[zdroj].head;
    grafik->vertices[zdroj].head = newEdge;
    return 1;
}



int insertEdge(GRAPH* grafik, int v1, int v2, int vaha) {
    if (v1 < 0 || v2 < 0 || v1 >= grafik->velkostGrafu || v2 >= grafik->velkostGrafu) {       
        return 1; 
    }
    if (v1 == v2) {
        return 1;
    }
    if (hranaExist(grafik, v1, v2)) {
        return 1;
    }
    if (!addEdgeToGraph(grafik, v1, v2, vaha) || !addEdgeToGraph(grafik, v2, v1, vaha)) {
        deleteEdge(grafik, v1, v2); 
        return 1;
    }
    return 0;
}


void printPath(int parent[], int vrcholCesty) {
    if (parent[vrcholCesty] == -1) {
        printf("%d", vrcholCesty);
        return;
    }
    printPath(parent, parent[vrcholCesty]);
    printf(", %d", vrcholCesty);
}


void printResults(int *firstLinePrinted, const char *message) {
    if (*firstLinePrinted) {
        printf("\n");
    } else {
        *firstLinePrinted = 1;
    }
    printf("%s", message);
}


int printPathToString(int parent[], int vrcholCesty, char *output) {
    if (parent[vrcholCesty] == -1) {
        return sprintf(output, "%d", vrcholCesty);
    }
    int len = printPathToString(parent, parent[vrcholCesty], output);
    return len + sprintf(output + len, ", %d", vrcholCesty);
}


void search(GRAPH* grafik, int zdroj, int ciel, int *firstLinePrinted) {
    if (zdroj < 0 || ciel < 0 || zdroj >= grafik->velkostGrafu || ciel >= grafik->velkostGrafu) {
        printResults(firstLinePrinted, "search failed");
        return;
    }

    MINHEAP *minHeap = createMinHeap(grafik->velkostGrafu);
    if (!minHeap) {
        return;
    }
    int distances[grafik->velkostGrafu];
    int parent[grafik->velkostGrafu];

    for (int i = 0; i < grafik->velkostGrafu; i++) {
        parent[i] = -1;
        distances[i] = INT_MAX;
        minHeap->nodes[i] = (HEAPNODE){i, INT_MAX};
        minHeap->pozicia[i] = i;
    }

    distances[zdroj] = 0;
    decreaseKey(minHeap, zdroj, distances[zdroj]);
    minHeap->velkost = grafik->velkostGrafu;

    while (minHeap->velkost > 0) {
        HEAPNODE minHeapNode = extractMin(minHeap);
        int currentVertex = minHeapNode.vertex;
        if (currentVertex == ciel) break;

        EDGE *currEdge = grafik->vertices[currentVertex].head;
        while (currEdge != NULL) {
            int adjacentVer = currEdge->vrchol2;
            if (isInMinHeap(minHeap, adjacentVer) && distances[currentVertex] != INT_MAX) {
                long long newDist = (long long)distances[currentVertex] + currEdge->vaha;
                if (newDist < distances[adjacentVer] && newDist < INT_MAX) {
                    distances[adjacentVer] = newDist;
                    parent[adjacentVer] = currentVertex;
                    decreaseKey(minHeap, adjacentVer, distances[adjacentVer]);
                }
            }
            currEdge = currEdge->next;
        }
    }

    if (distances[ciel] == INT_MAX) {
        printResults(firstLinePrinted, "search failed");
    } else {
        char output[1024];
        int length = snprintf(output, sizeof(output), "%d: [", distances[ciel]);
        if (parent[ciel] != -1) {
            length += printPathToString(parent, ciel, output + length);
        }
        snprintf(output + length, sizeof(output) - length, "]");
        printResults(firstLinePrinted, output);
    }

    free(minHeap->nodes);
    free(minHeap->pozicia);
    free(minHeap);
}



int updateEdge(GRAPH* grafik, int v1, int v2, int zmenaVahy) {
    int updated = 0;  
    for (EDGE* aktualnaHrana = grafik->vertices[v1].head; aktualnaHrana != NULL; aktualnaHrana = aktualnaHrana->next) {
        if (aktualnaHrana->vrchol2 == v2) {
            if (aktualnaHrana->vaha + zmenaVahy < 0) { 
                return -1; 
            }
            aktualnaHrana->vaha += zmenaVahy;
            updated = 1; 
            break; 
        }
    }

    for (EDGE* aktualnaHrana = grafik->vertices[v2].head; aktualnaHrana != NULL; aktualnaHrana = aktualnaHrana->next) {
        if (aktualnaHrana->vrchol2 == v1) {
            if (aktualnaHrana->vaha + zmenaVahy < 0) { 
                return -1;
            }
            aktualnaHrana->vaha += zmenaVahy;
            updated = 1;
            break;
        }
    }
    return updated ? 0 : -1;  
}




void freeGraph(GRAPH* grafik) {
    for (int i = 0; i < grafik->velkostGrafu; i++) {
        EDGE* current = grafik->vertices[i].head;
        while (current != NULL) {
            EDGE* temp = current;
            current = current->next;
            free(temp);
        }
    }
    free(grafik->vertices);
    free(grafik);
}



int main() {
    int N, M;
    scanf("%d %d", &N, &M);
    char command;
    int zdroj, ciel; 
    int zmenaVahy;
    GRAPH* grafik = createGraph(N);
    if (!grafik) {
        return 1;
    }

    int v1, v2, vaha, firstLinePrinted = 0;
    char paren1, comma1, comma2, paren2;
    for (int i = 0; i < M; i++) {
        scanf(" %c%d%c%d%c%d%c", &paren1, &v1, &comma1, &v2, &comma2, &vaha, &paren2);
        if (insertEdge(grafik, v1, v2, vaha) == 1) {
            char vypisChyby[50];
                sprintf(vypisChyby, "insert %d %d failed", v1, v2);
                printResults(&firstLinePrinted, vypisChyby);
        }
    }
    while (scanf(" %c", &command) != EOF) {
        switch (command) {
        case 'i':
            scanf(" %d%c%d%c%d", &v1, &comma1, &v2, &comma2, &vaha);
            if (insertEdge(grafik, v1, v2, vaha) == 1) {
                char vypisChyby[50];
                sprintf(vypisChyby, "insert %d %d failed", v1, v2);
                printResults(&firstLinePrinted, vypisChyby);
            }
            break;
        case 'd':
            scanf("%d %d", &v1, &v2);
            if (deleteEdge(grafik, v1, v2) == 0) {
                char vypisChyby[50];
                sprintf(vypisChyby, "delete %d %d failed", v1, v2);
                printResults(&firstLinePrinted, vypisChyby);
            }
            break;
        case 's':
            scanf("%d %d", &zdroj, &ciel);
            search(grafik, zdroj, ciel, &firstLinePrinted);
            break;
        case 'u':
            scanf("%d %d %d", &v1, &v2, &zmenaVahy);
            if (updateEdge(grafik, v1, v2, zmenaVahy) != 0) {
                char vypisChyby[50];
                sprintf(vypisChyby, "update %d %d failed", v1, v2);
                printResults(&firstLinePrinted, vypisChyby);
            }
            break;
        }
    }
    freeGraph(grafik);
    return 0;
}

